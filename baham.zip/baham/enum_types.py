from enum import Enum

class VehicleType(Enum):
    